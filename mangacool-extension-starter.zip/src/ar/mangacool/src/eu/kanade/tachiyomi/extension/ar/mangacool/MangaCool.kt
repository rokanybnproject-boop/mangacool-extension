package eu.kanade.tachiyomi.extension.ar.mangacool

import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.model.SMangaUpdate
import keiyoushi.annotation.Source
import keiyoushi.network.get
import keiyoushi.source.KeiSource
import keiyoushi.utils.asJsoup
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.jsoup.nodes.Document
import java.time.LocalDate
import java.time.ZoneOffset

@Source
abstract class MangaCool : KeiSource() {

    override suspend fun getPopularManga(page: Int): MangasPage = fetchList(
        listUrl(page, sort = "views"),
    )

    override suspend fun getLatestUpdates(page: Int): MangasPage = fetchList(
        listUrl(page, sort = "latest"),
    )

    override suspend fun getSearchMangaList(
        page: Int,
        query: String,
        filters: FilterList,
    ): MangasPage {
        if (query.isBlank()) return fetchList(listUrl(page))

        // Confirmed from the user's saved MangaCool search page: the query key is `search`.
        val document = client.get(listUrl(page, query = query)).asJsoup()
        return MangasPage(parseMangaCards(document), hasNextPage(document, page))
    }

    override suspend fun getMangaByUrl(url: HttpUrl): SManga? {
        val sourceHost = baseUrl.toHttpUrl().host
        if (url.host != sourceHost && url.host != "www.$sourceHost") return null
        val segments = url.pathSegments
        val slug = when (segments.firstOrNull()) {
            "manga" -> segments.getOrNull(1)
            // Also allow pasting a reader URL into the source search box.
            "reader" -> segments.getOrNull(1)
            else -> null
        }?.takeIf { it.isNotBlank() } ?: return null

        return SManga.create().apply {
            this.url = "/manga/$slug"
            title = slug.replace('-', ' ')
        }
    }

    override fun getMangaUrl(manga: SManga): String = absoluteSiteUrl(manga.url)

    override suspend fun fetchMangaUpdate(
        manga: SManga,
        chapters: List<SChapter>,
        fetchDetails: Boolean,
        fetchChapters: Boolean,
    ): SMangaUpdate {
        // The manga details and the complete chapter list are present in the same HTML page.
        val document = client.get(getMangaUrl(manga)).asJsoup()
        val heading = document.selectFirst("h1")
            ?: throw Exception("MangaCool: could not find the manga title")

        manga.apply {
            title = heading.ownText().ifBlank { heading.text() }
            thumbnail_url = document.selectFirst("meta[property=og:image]")?.attr("content")
                ?.takeIf { it.isNotBlank() }
                ?: document.selectFirst("#mangaCover")?.absUrl("src")
            description = document.selectFirst("h3:containsOwn(نبذة عن العمل)")
                ?.parent()
                ?.selectFirst("p")
                ?.text()
                ?: document.selectFirst("meta[name=description]")?.attr("content").orEmpty()
            genre = document.select("a[href*='/manga-list?genres=']")
                .map { it.text() }
                .distinct()
                .joinToString()

            val statusText = heading.parent()?.text().orEmpty()
            status = when {
                statusText.contains("مستمرة") || statusText.contains("جارية") -> SManga.ONGOING
                statusText.contains("مكتملة") || statusText.contains("منتهية") -> SManga.COMPLETED
                else -> SManga.UNKNOWN
            }
        }

        return SMangaUpdate(manga, parseChapterList(document))
    }

    override suspend fun getPageList(chapter: SChapter): List<Page> {
        val document = client.get(absoluteSiteUrl(chapter.url)).asJsoup()
        // MangaCool wraps each image in a container with the `manga-page` class.
        val imageUrls = document.select("#reader-content .manga-page img")
            .mapNotNull { image ->
                val rawUrl = image.attr("data-src").takeIf { it.isNotBlank() }
                    ?: image.attr("src").takeIf { it.isNotBlank() }
                    ?: return@mapNotNull null
                val absolute = if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) {
                    rawUrl
                } else {
                    image.absUrl(if (image.hasAttr("data-src")) "data-src" else "src")
                }
                absolute.takeIf { it.startsWith("http://") || it.startsWith("https://") }
            }
            .distinct()

        return imageUrls.mapIndexed { index, imageUrl ->
            Page(index = index, url = imageUrl, imageUrl = imageUrl)
        }
    }

    private suspend fun fetchList(url: HttpUrl): MangasPage {
        val document = client.get(url).asJsoup()
        val mangas = parseMangaCards(document)
        return MangasPage(mangas, hasNextPage(document, url.queryParameter("page")?.toIntOrNull() ?: 1))
    }

    private fun listUrl(page: Int, sort: String? = null, query: String? = null): HttpUrl =
        "$baseUrl/manga-list".toHttpUrl().newBuilder().apply {
            addQueryParameter("page", page.toString())
            sort?.let { addQueryParameter("sort", it) }
            query?.takeIf { it.isNotBlank() }?.let { addQueryParameter("search", it) }
        }.build()

    private fun parseMangaCards(document: Document): List<SManga> =
        document.select("div.manga-card > a[href*='/manga/']").mapNotNull { anchor ->
            val href = anchor.absUrl("href").toHttpUrlOrNull() ?: return@mapNotNull null
            val segments = href.pathSegments
            if (segments.size != 2 || segments.firstOrNull() != "manga") return@mapNotNull null
            val image = anchor.selectFirst("img") ?: return@mapNotNull null
            val rawTitle = anchor.selectFirst("h2, h3, .manga-title, .manga-card-title, p.font-bold")
                ?.text()
                ?.takeIf { it.isNotBlank() }
                ?: image.attr("alt")
                    .removePrefix("مانجا مشابهة")
                    .removePrefix("غلاف مانجا")
                    .removePrefix("مانجا")
                    .trim()
            if (rawTitle.isBlank()) return@mapNotNull null

            val thumbnail = image.absUrl("src").ifBlank { image.absUrl("data-src") }
            SManga.create().apply {
                url = "/manga/${segments[1]}"
                title = rawTitle
                thumbnail_url = thumbnail.takeIf { it.isNotBlank() }
            }
        }.distinctBy { it.url }

    private fun parseChapterList(document: Document): List<SChapter> =
        document.select(".manga-chapter a[href*='/reader/']").mapNotNull { anchor ->
            val chapterUrl = anchor.absUrl("href").toHttpUrlOrNull() ?: return@mapNotNull null
            val segments = chapterUrl.pathSegments
            if (segments.size < 3 || segments.firstOrNull() != "reader") return@mapNotNull null

            val visibleText = anchor.text()
            val chapterNumber = CHAPTER_NUMBER.find(chapterUrl.encodedPath)?.groupValues?.getOrNull(1)
            val name = chapterNumber?.let { "الفصل $it" }
                ?: CHAPTER_NAME.find(visibleText)?.value
                ?: visibleText
            SChapter.create().apply {
                url = chapterUrl.encodedPath
                this.name = name
                date_upload = parseDate(visibleText)
            }
        }.distinctBy { it.url }

    private fun parseDate(text: String): Long {
        // Dates in saved MangaCool pages include Unicode right-to-left marks around slashes.
        val normalized = text.filterNot { it == '\u200E' || it == '\u200F' || it == '\u202A' || it == '\u202B' || it == '\u202C' }
        val match = DATE.find(normalized) ?: return 0L
        return runCatching {
            val day = match.groupValues[1].toInt()
            val month = match.groupValues[2].toInt()
            val year = match.groupValues[3].toInt()
            LocalDate.of(year, month, day)
                .atStartOfDay()
                .toInstant(ZoneOffset.UTC)
                .toEpochMilli()
        }.getOrDefault(0L)
    }

    private fun hasNextPage(document: Document, currentPage: Int): Boolean {
        if (document.selectFirst("a[rel=next], a[aria-label*=التالي], a[aria-label*=Next]") != null) {
            return true
        }
        val next = currentPage + 1
        return document.select("a[href]").any { element ->
            val target = element.absUrl("href").toHttpUrlOrNull() ?: return@any false
            target.queryParameter("page")?.toIntOrNull() == next
        }
    }

    private fun absoluteSiteUrl(pathOrUrl: String): String = when {
        pathOrUrl.startsWith("https://") || pathOrUrl.startsWith("http://") -> pathOrUrl
        pathOrUrl.startsWith("/") -> baseUrl + pathOrUrl
        else -> "$baseUrl/$pathOrUrl"
    }

    private companion object {
        val CHAPTER_NUMBER = Regex("/reader/[^/]+/(\\d+(?:\\.\\d+)?)")
        val CHAPTER_NAME = Regex("الفصل\\s*\\d+(?:\\.\\d+)?")
        val DATE = Regex("(\\d{1,2})\\s*/\\s*(\\d{1,2})\\s*/\\s*(\\d{4})")
    }
}
