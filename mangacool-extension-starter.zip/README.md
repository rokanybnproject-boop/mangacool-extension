# MangaCool extension starter for Mihon / Tachiyomi

This is a source project for a custom Arabic MangaCool extension. The provided saved HTML snapshots confirmed the `/manga/<slug>` work path, `/reader/<slug>/<chapter>` chapter path, the `search` query parameter, `div.manga-card` result cards, chapter links under `.manga-chapter`, and image elements using `#reader-content img.manga-page`.

This is source code, not a prebuilt APK. The site could not be queried live from the development environment, so the APK must be built and tested in Mihon before relying on it. See `README_AR.md` for Android-phone-friendly build steps using GitHub Actions.
